/**
 * Classes for accepting/receiving transport orders from somewhere else.
 */
package org.opentcs.kernel.extensions.xmlhost.orders;
