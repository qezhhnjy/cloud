/**
 * XML binding classes for kernel status messages sent via a plain XML/TCP
 * interface.
 */
package org.opentcs.kernel.extensions.xmlhost.status.binding;
