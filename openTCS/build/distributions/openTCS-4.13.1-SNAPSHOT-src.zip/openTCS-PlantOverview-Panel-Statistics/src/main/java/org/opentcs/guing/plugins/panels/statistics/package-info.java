/**
 * A plugin panel providing a statistics report based on dump file data.
 */
package org.opentcs.guing.plugins.panels.statistics;
