/*
 * openTCS copyright information:
 * Copyright (c) 2014 Fraunhofer IML
 *
 * This program is free software and subject to the MIT license. (For details,
 * see the licensing information (LICENSE.txt) you should have received with
 * this copy of the software.)
 */
@XmlSchema(xmlns = {@javax.xml.bind.annotation.XmlNs(
      prefix = "xsi", namespaceURI = "http://www.w3.org/2001/XMLSchema-instance"),
                    @javax.xml.bind.annotation.XmlNs(
                        prefix = "xs",
                        namespaceURI = "http://www.w3.org/2001/XMLSchema")})
package org.opentcs.guing.persistence.legacy;

import javax.xml.bind.annotation.XmlSchema;
