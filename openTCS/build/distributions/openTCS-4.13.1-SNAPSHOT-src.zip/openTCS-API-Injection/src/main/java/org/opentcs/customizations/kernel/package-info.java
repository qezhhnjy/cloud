/**
 * Components supporting extension and customization of the openTCS kernel application.
 */
package org.opentcs.customizations.kernel;
